class Item_search {
    constructor(index, name, peoplenum) {
        this.index = index;
        this.name = name;
        this.peoplenum = peoplenum;
    }
}
class searchPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__city = new ObservedPropertyObjectPU(['北京', '天津', '上海', '武汉', '广州', '深圳', '杭州', '南京', '郑州', '南宁', '东京', '纽约',], this, "city");
        this.items_search = [
            new Item_search(1, '大连 洱海', 3082),
            new Item_search(2, '故宫博物馆', 2850),
            new Item_search(3, '杭州西湖 雷峰塔', 2140),
            new Item_search(4, '去广西柳州嗦螺丝粉', 2020),
            new Item_search(5, '厦门 鼓浪屿', 1650),
            new Item_search(6, '武汉的樱花开了', 1500),
            new Item_search(7, '潮州 美食之都', 1480),
            new Item_search(8, '广州大剧院', 1369),
            new Item_search(9, '重庆的山路', 1045),
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.city !== undefined) {
            this.city = params.city;
        }
        if (params.items_search !== undefined) {
            this.items_search = params.items_search;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__city.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__city.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get city() {
        return this.__city.get();
    }
    set city(newValue) {
        this.__city.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(32:5)");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                colors: [[0x062A5C, 0.0], [0xFFF9E3, 1.0]] //背景渐变
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/Index.ets(34:7)");
            Stack.margin({ bottom: 5, top: 20 });
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //搜索框
            Row.create();
            Row.debugLine("pages/Index.ets(37:11)");
            //搜索框
            Row.width('100%');
            //搜索框
            Row.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                //搜索框
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('搜索');
            Text.debugLine("pages/Index.ets(38:13)");
            Text.fontColor('#FFF6D2');
            Text.fontSize(28);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //搜索框
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(46:10)");
            Row.margin({ left: 5 });
            Row.width('100%');
            Row.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777223, "type": 20000, params: [], "bundleName": "com.example.search", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(47:12)");
            Image.width(35);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Stack.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '广西涠洲岛 勇敢的人先享受...' });
            TextInput.debugLine("pages/Index.ets(56:7)");
            TextInput.backgroundColor('#F8F8F8');
            TextInput.width('90%');
            TextInput.margin({ bottom: 5 });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //城市列表
            Grid.create();
            Grid.debugLine("pages/Index.ets(63:7)");
            //城市列表
            Grid.columnsTemplate('1fr 1fr 1fr 1fr');
            //城市列表
            Grid.rowsTemplate('1fr 1fr 1fr');
            //城市列表
            Grid.height('24%');
            if (!isInitialRender) {
                //城市列表
                Grid.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const cityname = _item;
                {
                    const isLazyCreate = true && (Grid.willUseProxy() === true);
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        GridItem.create(deepRenderFunction, isLazyCreate);
                        GridItem.debugLine("pages/Index.ets(65:11)");
                        if (!isInitialRender) {
                            GridItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        GridItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Button.createWithLabel(cityname);
                            Button.debugLine("pages/Index.ets(66:13)");
                            Button.type(ButtonType.Capsule);
                            Button.fontColor('#042450');
                            Button.backgroundColor('#FBFBFB');
                            Button.width('90');
                            Button.borderRadius(50);
                            if (!isInitialRender) {
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Button.pop();
                        GridItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Button.createWithLabel(cityname);
                            Button.debugLine("pages/Index.ets(66:13)");
                            Button.type(ButtonType.Capsule);
                            Button.fontColor('#042450');
                            Button.backgroundColor('#FBFBFB');
                            Button.width('90');
                            Button.borderRadius(50);
                            if (!isInitialRender) {
                                Button.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Button.pop();
                        GridItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.city, forEachItemGenFunction, cityname => cityname, false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        //城市列表
        Grid.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(78:7)");
            Row.margin({ bottom: 5 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/Index.ets(79:9)");
            Button.backgroundColor('');
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Index.ets(80:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('查看更多');
            Text.debugLine("pages/Index.ets(81:11)");
            Text.fontColor('#FFF6D2');
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.search", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(84:11)");
            Image.width(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Button.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //热门搜索
            Row.create();
            Row.debugLine("pages/Index.ets(94:7)");
            //热门搜索
            Row.width('80%');
            //热门搜索
            Row.justifyContent(FlexAlign.Start);
            //热门搜索
            Row.margin({ bottom: 10 });
            if (!isInitialRender) {
                //热门搜索
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('热门搜索');
            Text.debugLine("pages/Index.ets(95:9)");
            Text.fontSize(20);
            Text.fontColor('#FFF6D2');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        //热门搜索
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(103:7)");
            Column.backgroundColor('#F7F7F7');
            Column.opacity(0.75);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Index.ets(104:9)");
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/Index.ets(108:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/Index.ets(109:17)");
                            Row.width('95%');
                            Row.justifyContent(FlexAlign.SpaceBetween);
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/Index.ets(110:19)");
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (item.index <= 3) { //判断是否为热搜前三
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Stack.create();
                                        Stack.debugLine("pages/Index.ets(112:23)");
                                        if (!isInitialRender) {
                                            Stack.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Image.create({ "id": 16777222, "type": 20000, params: [], "bundleName": "com.example.search", "moduleName": "entry" });
                                        Image.debugLine("pages/Index.ets(113:25)");
                                        Image.width(35);
                                        Image.margin({ left: 5, top: 18 });
                                        if (!isInitialRender) {
                                            Image.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item.index.toString());
                                        Text.debugLine("pages/Index.ets(116:25)");
                                        Text.fontSize(27);
                                        Text.fontColor('#000000');
                                        Text.margin({ left: 7, top: 18 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                    Stack.pop();
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(' ' + item.name);
                                        Text.debugLine("pages/Index.ets(121:23)");
                                        Text.fontSize(20);
                                        Text.fontColor('#000000');
                                        Text.margin({ top: 18 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item.index.toString());
                                        Text.debugLine("pages/Index.ets(126:23)");
                                        Text.fontSize(27);
                                        Text.fontColor('#000000');
                                        Text.margin({ left: 13, top: 20 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create('  ' + item.name);
                                        Text.debugLine("pages/Index.ets(130:23)");
                                        Text.fontSize(20);
                                        Text.fontColor('#000000');
                                        Text.margin({ top: 18 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Row.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.peoplenum.toString());
                            Text.debugLine("pages/Index.ets(137:19)");
                            Text.fontSize(20);
                            Text.fontColor('#000000');
                            Text.margin({ top: 23 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/Index.ets(109:17)");
                            Row.width('95%');
                            Row.justifyContent(FlexAlign.SpaceBetween);
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/Index.ets(110:19)");
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (item.index <= 3) { //判断是否为热搜前三
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Stack.create();
                                        Stack.debugLine("pages/Index.ets(112:23)");
                                        if (!isInitialRender) {
                                            Stack.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Image.create({ "id": 16777222, "type": 20000, params: [], "bundleName": "com.example.search", "moduleName": "entry" });
                                        Image.debugLine("pages/Index.ets(113:25)");
                                        Image.width(35);
                                        Image.margin({ left: 5, top: 18 });
                                        if (!isInitialRender) {
                                            Image.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item.index.toString());
                                        Text.debugLine("pages/Index.ets(116:25)");
                                        Text.fontSize(27);
                                        Text.fontColor('#000000');
                                        Text.margin({ left: 7, top: 18 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                    Stack.pop();
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(' ' + item.name);
                                        Text.debugLine("pages/Index.ets(121:23)");
                                        Text.fontSize(20);
                                        Text.fontColor('#000000');
                                        Text.margin({ top: 18 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item.index.toString());
                                        Text.debugLine("pages/Index.ets(126:23)");
                                        Text.fontSize(27);
                                        Text.fontColor('#000000');
                                        Text.margin({ left: 13, top: 20 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create('  ' + item.name);
                                        Text.debugLine("pages/Index.ets(130:23)");
                                        Text.fontSize(20);
                                        Text.fontColor('#000000');
                                        Text.margin({ top: 18 });
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Row.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.peoplenum.toString());
                            Text.debugLine("pages/Index.ets(137:19)");
                            Text.fontSize(20);
                            Text.fontColor('#000000');
                            Text.margin({ top: 23 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.items_search, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new searchPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
export {};
//# sourceMappingURL=Index.js.map