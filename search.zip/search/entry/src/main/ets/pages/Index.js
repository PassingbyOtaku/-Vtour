struct searchPage extends   {
    constructor() { }
    build() {
            .width('100%')
            .height('100%')
            .linearGradient({
            colors: [[0x062A5C, 0.0], [0xFFF9E3, 1.0]]
        });
    }
}
export {};
//# sourceMappingURL=Index.js.map